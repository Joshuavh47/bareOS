#include <bareio.h>
#include <barelib.h>
#include <shell.h>
#include <thread.h>
#include <sleep.h>

#define PROMPT "bareOS$ "  /*  Prompt printed by the shell to the user  */


/*
 * 'shell' loops forever, prompting the user for input, then calling a function based
 * on the text read in from the user.
 */
byte shell(char* arg) {
    unsigned char last_ret=0;
    while(1){
        printf(PROMPT);
        char buff[2048];
        char actual[2048];
        
        
        

        int buff_ptr=0;
        int actual_ptr=0;
        int space=0;
        int cmd_ptr=-1;
        char ch;
        int count=0;
        while(actual[count]!='\0'){
            actual[count]='\0';
            count++;

        }
        while((ch=uart_getc())!='\n'&&(ch<128)){
            //char ch=uart_getc();
            //printf("%d ",ch);
            
            
            if((ch==8||ch==127)&&buff_ptr>0){
                
                printf("\b\b \b");
                
                buff[buff_ptr]='\0';
                buff_ptr--;
                
                continue;
            }
            else if((ch==8||ch==127)&&buff_ptr==0){
                printf("\b \b");
                continue;
            }
            if(ch!='\n'){
                buff[buff_ptr]=ch;
                buff_ptr++;
            }
            
            
            
            
        }
        // for(int i=0;i<2048;i++){
        //         uart_putc(buff[i]);
        // }
        // buff_ptr--;
        for(int i=0;i<buff_ptr;i++){
            if(space!=1&&buff[i]==' '){
                cmd_ptr=actual_ptr;
                space=1;
            }
            if(i<buff_ptr&&buff[i]=='$'&&buff[i+1]=='?'){
                //printf("%d ",last_ret);
                char num[3];
                int places=0;
                int tempNum=last_ret;
                if(last_ret<10){
                    places=1;
                }
                if(last_ret>=10&&last_ret<100){
                    places=2;
                }
                else if(last_ret>=100){
                    places=3;
                }
                //printf("%d ",places);
                for(int j=0;j<places;j++){
                    num[j]=(tempNum%10);
                    tempNum/=10;
                    
                }
                //printf("%d ",places-1);
                //printf("%d ",places);
                for(int j=places-1;j>=0;j--){
                    //printf("hello");
                    actual[actual_ptr]=num[j]+48;
                    actual_ptr++;
                    //uart_putc(num[j]);
                    //uart_putc(' ');
                    
                    //printf("%d ",num[j]+48);
                }
                for(int j=0;j<20;j++){
                    //printf("%d ",actual[j]);
                }
                
                i++;
                continue;
            }
            else{
                
                actual[actual_ptr]=buff[i];
                actual_ptr++;
                
            }
        }
        actual[actual_ptr]='\0';
        if(buff[0]=='\n'){
            continue;
        }
        if(actual_ptr==0){
            // printf("\n");
            continue;
        }
        if(actual_ptr>1024){
            printf("Command too long!\n");
            continue;
        }
        if(space!=1){
            cmd_ptr=actual_ptr;
        }
        
        int cmp=0;
        int same=0;
        while("hello"[cmp]!='\0'&&cmp<=cmd_ptr){
            if("hello"[cmp]==actual[cmp]){
                same++;
                
            }
            cmp++;
        }
        if(same==5&&same==cmd_ptr){
            int32 thread1=create_thread(builtin_hello,actual,2048);
            resume_thread(thread1);
            last_ret=join_thread(thread1);
            
            for(int i=0;i<buff_ptr;i++){
                buff[i]='\0';
            }
            for(int i=0;i<actual_ptr;i++){
                actual[i]='\0';
            }
            continue;
        }
        cmp=0;
        same=0;
        while("echo"[cmp]!='\0'&&cmp<=cmd_ptr){
            if("echo"[cmp]==actual[cmp]){
                same++;
            }
            cmp++;
        }
        if(same==4&&same==cmd_ptr){
            int32 thread2=create_thread(builtin_echo,actual,2048);
            resume_thread(thread2);
            last_ret=join_thread(thread2);
            
            for(int i=0;i<buff_ptr;i++){
                buff[i]='\0';
            }
            for(int i=0;i<actual_ptr;i++){
                actual[i]='\0';
            }
            continue;
        }
        else{
            printf("Unknown command\n");
            continue;
        }

    }
    return 0;
}


